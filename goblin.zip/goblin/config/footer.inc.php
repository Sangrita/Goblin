</div>
<!-- 主要内容结束 -->


<!-- 底部版权信息 -->
<!-- <table border=0>
	<tr>
		<td>Powered by<a href="http://www.baidu.com">Goblin论坛</a></td>
	</tr>
</table> -->
<div id="footer">Powered by<a href="http://www.baidu.com">Goblin论坛</a></div>
</div>
</body>
</html>